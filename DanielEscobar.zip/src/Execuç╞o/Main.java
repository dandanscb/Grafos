/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Execução;

import Estrutura.*;
import Funções.*;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author a16026
 */
public class Main {

    public static void main(String[] args) {

        /*for (int k = 1; k < 7; k++) {
        System.out.printf("Iteracao 6\n");
        String nome = "Grafo";
        Leitura arq = new Leitura("tp1_file_006.csv");
        BuscaEmProfundidade busca = new BuscaEmProfundidade(1, arq);
        busca.DFS();
        Escrita esc = new Escrita(busca.getNum_vertice(), busca.getD(), busca.getF(), "Saida6M.csv");
        }*/
        String representacao = null;
        String f = null;
        String entrada = null;
        String saida = null;
        int tipo = 1;
        int raiz = 0;

        for (int i = 0; i < args.length; i++) {
            if ("-rep".equals(args[i])) {
                representacao = args[i + 1];
                i++;
            } else if ("-f".equals(args[i])) {
                f = args[i + 1];;
                i++;
            } else if ("-csvorigem".equals(args[i])) {
                entrada = args[i + 1];
                i++;
            } else if ("-csvdestino".equals(args[i])) {
                saida = args[i + 1];
                i++;
            } else if ("-grafo".equals(args[i])) {
                tipo = Integer.parseInt(args[i + 1]);
                i++;
            } else if ("-verticeinicial".equals(args[i])) {
                raiz = Integer.parseInt(args[i + 1]);
                i++;
            }

        }

        Leitura arquivo = new Leitura(entrada);
        BuscaEmProfundidade DFS = new BuscaEmProfundidade(tipo, arquivo, saida);
        BuscaEmLargura BFS = new BuscaEmLargura(tipo, arquivo, saida);
        if (representacao.equals("DFS")) {
            if (f.equals("i")) {
                DFS.DFS_Iterativo();
            } else {
                DFS.DFS();
            }
        } else {
            BFS.BFS(raiz);
        }

    }

}

